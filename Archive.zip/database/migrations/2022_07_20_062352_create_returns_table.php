<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateReturnsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('returns', function (Blueprint $table) {
            $table->id();
            $table->string('return_no');
            $table->integer('branch_id');
            $table->integer('cashier_id');
            $table->integer('product_id');
            $table->integer('price');
            $table->integer('discount')->default(0);
            $table->integer('quantity');
            $table->string('customer')->nullable();
            $table->string('note')->nullable();
            $table->enum('return_channel', ['profifle','normal'])->default('normal');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('returns');
    }
}
