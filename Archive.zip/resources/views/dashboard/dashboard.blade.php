@extends('layouts.app')
@section('PageTitle', 'Home')
@section('css')
    <style>
        .card {
            margin-bottom: 15px;
            padding: 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background-color: #f8f9fa;
            border: none;
            border-radius: 10px;
        }

        .card-title {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .card-text {
            font-size: 18px;
            color: #333;
            margin-bottom: 5px;
        }

        .card-description {
            font-size: 12px;
            color: #777;
        }

        .stats-section {
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
        }

        .stats-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .stats-list {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .stats-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid #ced4da;
            border-radius: 10px;
            padding: 10px;
            margin-bottom: 10px;
        }

        .stats-label {
            font-size: 14px;
            font-weight: bold;
            margin-right: 10px;
        }

        .stats-value {
            font-size: 18px;
            font-weight: bold;
        }
    </style>
@endsection
@section('content')
    <section id="content" style="background: rgb(240, 240, 240)">
        <div class="content-wrap">
            <div class="container">



                <div class="col-md-12">
                    <form class="row" action="{{ route('admin.view_cashier_dashboard') }}" method="POST" id="date_form">
                        @csrf
                        <div class="row">  
                            <div class="col-md-3">
                                <label for="staff_id" class="form-label">Select Cashier</label>
                                <select class="form-select form-select-sm" id="staff_id" name="staff_id" required>
                                    @foreach ($staffss as $staffs)
                                        <option value="{{ $staffs->id }}">{{ $staffs->first_name.' '.$staffs->last_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="date_type" class="form-label">Select Date Type</label>
                                <select class="form-select form-select-sm" id="date_type" name="date_type">
                                    <option value="single" {{ isset($date_type) && $date_type === 'single' ? 'selected' : '' }}>Single Date</option>
                                    <option value="range" {{ isset($date_type) && $date_type === 'range' ? 'selected' : '' }}>Date Range</option>
                                </select>
                            </div>
                            <div class="col-md-4"> 
                                 <div id="single_date_fields" style="{{ isset($date_type) && $date_type === 'single' ? 'display: block;' : 'display: none;' }}">
                                    <label for="selected_date" class="form-label">Selected Date</label>
                                    <input type="date" class="form-control form-control-sm" id="selected_date" name="selected_date" {{ isset($date_type) && $date_type === 'single' ? 'required' : '' }} value="{{ isset($selected_date) ? $selected_date : '' }}">
                                </div>
                                <div id="range_date_fields" style="{{ isset($date_type) && $date_type === 'range' ? 'display: block;' : 'display: none;' }}">
                                    <label for="start_date" class="form-label">Start Date</label>
                                    <input type="date" class="form-control form-control-sm" id="start_date" name="start_date" {{ isset($date_type) && $date_type === 'range' ? 'required' : '' }} value="{{ isset($start_date) ? $start_date : '' }}">
                                    <label for="end_date" class="form-label">End Date</label>
                                    <input type="date" class="form-control form-control-sm" id="end_date" name="end_date" {{ isset($date_type) && $date_type === 'range' ? 'required' : '' }} value="{{ isset($end_date) ? $end_date : '' }}">
                                </div>
                            </div>

                            <div class="col-md-2">  <label class="invisible">Submit</label>
                                <button type="submit" class="btn btn-sm btn-primary text-white col-12">View Stats</button>
                            </div>
                        </div>
                        
                    </form>
                </div>
                
                @if(isset($staff_id))

                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Cash Balance</h5>
                                    <?php
                                    $result = $cashSales - ($cashExpenses + $cashReturns) + $cashCreditPayments + $cashDepositPayments - $cashCreditToday + $CreditPaymentSummary['cash'] + ($cashFundTransfer);
                                    $formattedResult = number_format($result);
                                    ?>

                                    <p class="card-text">&#8358;{{ $formattedResult }}</p>
                                    <h6 class="card-subtitle mb-2 text-muted">
                                        {{ 'Sales: ' . $cashSales . ', Returns: ' . $cashReturns . ', Expenses: ' . $cashExpenses . ', Repayments: ' . $cashCreditPayments . ', Deposit ' . $cashDepositPayments . ', Cash Credit: ' . $cashCreditToday . ', CC Repayment: ' . $CreditPaymentSummary['cash'].', Funds Transfer '.$cashFundTransfer }}
                                    </h6>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Transfer Balance</h5>

                                    <?php
                                    $transferResult = $transferSales - ($transferExpenses + $transferReturns) + $transferCreditPayments + $transferDepositPayments + $CreditPaymentSummary['transfer'] + ($transferFundTransfer);
                                    $formattedTransferResult = number_format($transferResult);
                                    ?>

                                    <p class="card-text">&#8358;{{ $formattedTransferResult }}</p>

                                    <h6 class="card-subtitle mb-2 text-muted">
                                        {{ 'Sales: ' . $transferSales . ', Returns: ' . $transferReturns . ', Expenses: ' . $transferExpenses . ', Repayments: ' . $transferCreditPayments . ', Deposit ' . $transferDepositPayments . ', CC Repayment: ' . $CreditPaymentSummary['transfer'].', Funds Transfer '.$transferFundTransfer }}
                                    </h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">POS Balance</h5>
                                    <?php
                                    $posResult = $posSales - ($posExpenses + $posReturns) + $posCreditPayments + $posDepositPayments + $CreditPaymentSummary['pos'] + ($posFundTransfer);
                                    $formattedPosResult = number_format($posResult);
                                    ?>

                                    <p class="card-text">&#8358;{{ $formattedPosResult }}</p>

                                    <h6 class="card-subtitle mb-2 text-muted">
                                        {{ 'Sales: ' . $posSales . ', Returns: ' . $posReturns . ', Expenses: ' . $posExpenses . ', Repayments: ' . $posCreditPayments . ', Deposit ' . $posDepositPayments . ', CC Repayment: ' . $CreditPaymentSummary['pos'].', Funds Transfer '.$posFundTransfer }}
                                    </h6>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>

                <div class="container mt-1">
                    <div class="stats-section">
                        <h3 class="stats-title">
                            @if (isset($start_date) && isset($end_date))
                            Stats for {{ \Carbon\Carbon::parse($start_date)->toFormattedDateString() }}
                            - {{ \Carbon\Carbon::parse($end_date)->toFormattedDateString() }}
                            ({{ \Carbon\Carbon::parse($start_date)->diffInDays($end_date) }} days apart)
                        @elseif (isset($selected_date))
                            Stats for {{ \Carbon\Carbon::parse($selected_date)->toFormattedDateString() }}
                        @else
                            Today's Stats &gt;&gt;&gt;
                        @endif
                        
                        </h3>
                        <div class="row">

                            <div class="col-md-6">
                                <ul class="iconlist fw-medium">

                                    <li class="border border-primary py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Gross Sales: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($grossSales, 0) }}</span></span>
                                        <span style="margin-left: auto;"></span>
                                    </li>
                                    <li class="border border-success py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Total Returns: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($totalReturn, 0) }}</span></span>
                                        <span style="margin-left: auto;">
                                            ({{ 'Cash: ' . number_format($cashReturns, 0) . ' POS: ' . number_format($posReturns, 0) . ' Trans: ' . number_format($transferReturns, 0) }})</span>
                                    </li>
                                    <li class="border border-success py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Discounts: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($totalDiscounts - $returnDiscounts, 0) }}</span></span>
                                        <span
                                            style="margin-left: auto;">({{ 'Sales Discount: ' . number_format($totalDiscounts, 0) . ' Return Discount: ' . number_format($returnDiscounts, 0) }})
                                        </span>
                                    </li>
                                    <li class="border border-success py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Expenses: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($totalExpenses, 0) }}</span></span>
                                        <span style="margin-left: auto;">
                                            ({{ 'Cash: ' . number_format($cashExpenses, 0) . ' POS: ' . number_format($posExpenses, 0) . ' Trans: ' . number_format($transferExpenses, 0) }})</span>
                                    </li>

                                    <li class="border border-success py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Estimates: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($totalEstimate, 0) }}</span></span>
                                        <span style="margin-left: auto;"></span>
                                    </li>
                                   
                                   
                                    <li class="border border-success py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Today's Deposit: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($totalDepositPayments, 0) }}</span></span>
                                        <span style="margin-left: auto;"></span>
                                    </li>
                                    <li class="border border-success py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Walk-in Count: <span class="fw-bold"
                                                style="margin-left: 5px;">{{ number_format($uniqueSalesCount, 0) }}</span></span>
                                        <span style="margin-left: auto;"></span>
                                    </li>
                                   
                                    <li class="border border-success py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Total Cash Credit Balance Remaining: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format(@$TotalcashCredit, 0) }}</span></span>
                                        <span style="margin-left: auto;"></span>
                                    </li>

                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul class="iconlist fw-medium">

                                    <li class="border border-success py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Number of Item Sold: <span class="fw-bold"
                                                style="margin-left: 5px;">{{ number_format($totalItemsSold, 0) }}</span></span>
                                        <span style="margin-left: auto;"></span>
                                    </li>
                                    <li class="border border-danger py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Credit Sales: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($creditSales, 0) }}</span></span>
                                        <span style="margin-left: auto;"></span>
                                    </li>
                                    <li class="border border-danger py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Deposit Sales: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($depositSales, 0) }}</span></span>
                                        <span style="margin-left: auto;"></span>
                                    </li>

                                    <li class="border border-danger py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Cash Sales: <span class="fw-bold" style="margin-left: 5px;">
                                                &#8358;{{ number_format($cashSales - $cashReturns, 0) }}</span></span>
                                        <span
                                            style="margin-left: auto;">({{ 'Sales: ' . number_format($cashSales, 0) . ' Returns: ' . number_format($cashReturns, 0) }})
                                        </span>
                                    </li>

                                    <li class="border border-danger py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>POS Sales: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($posSales - $posReturns, 0) }}</span></span>
                                        <span
                                            style="margin-left: auto;">({{ 'Sales: ' . number_format($posSales, 0) . ' Returns: ' . number_format($posReturns, 0) }})
                                        </span>
                                    </li>

                                    <li class="border border-danger py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Transfer Sales: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($transferSales - $transferReturns, 0) }}
                                            </span></span>
                                        <span
                                            style="margin-left: auto;">({{ 'Sales: ' . number_format($transferSales, 0) . ' Returns: ' . number_format($transferReturns, 0) }})
                                        </span>
                                    </li>
                                    <li class="border border-danger py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Net Sales: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($grossSales - $totalDiscount - ($totalReturn - $returnDiscounts), 0) }}</span></span>
                                        <span
                                            style="margin-left: auto;">({{ 'Gross Sale: ' . number_format($grossSales, 0) . ' Sales Discount: ' . number_format($totalDiscount, 0) . ' Total Return: ' . number_format($totalReturn, 0) . ' Return Discount: ' . number_format($returnDiscounts, 0) }})
                                        </span>
                                    </li>
                                    <li class="border border-success py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Credit Payments: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($totalCreditPayments, 0) }}</span></span>
                                        <span style="margin-left: auto;">
                                            ({{ 'Cash: ' . number_format($cashCreditPayments, 0) . ' POS: ' . number_format($posCreditPayments, 0) . ' Trans: ' . number_format($transferCreditPayments, 0) }})</span>
                                    </li>

                                    <li class="border border-danger py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Gross Profit: <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($grossProfit - $totalDiscounts - ($returnProfit - $returnDiscounts), 0) }}</span></span>
                                        <span
                                            style="margin-left: auto;">({{ 'Sales Profit: ' . number_format($grossProfit, 0) . ' Sales Discount: ' . number_format($totalDiscount, 0) . ' Return Profit: ' . number_format($returnProfit, 0) . ' Return Discount: ' . number_format($returnDiscounts, 0) }})
                                        </span>
                                    </li>
                                    <li class="border border-danger py-2 px-3 rounded mb-2"
                                        style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>Net Profit(approx.): <span class="fw-bold"
                                                style="margin-left: 5px;">&#8358;{{ number_format($grossProfit - $totalDiscounts - ($returnProfit - $returnDiscounts) - $totalExpenses, 0) }}</span></span>
                                        <span
                                            style="margin-left: auto;">({{ 'Sales Profit: ' . number_format($grossProfit, 0) . ' Sales Discount: ' . number_format($totalDiscount, 0) . ' Return Profit: ' . number_format($returnProfit, 0) . ' Return Discount: ' . number_format($returnDiscounts, 0) . ' Expenses: ' . number_format($totalExpenses, 0)}})
                                        </span>
                                    </li>
                                   
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                @endif

             


            </div>
        </div>
    </section>
@endsection

@section('js')
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var dateTypeSelect = document.getElementById('date_type');
        var singleDateFields = document.getElementById('single_date_fields');
        var rangeDateFields = document.getElementById('range_date_fields');

        // Function to show/hide fields based on selected date type
        function toggleDateFields() {
            if (dateTypeSelect.value === 'single') {
                singleDateFields.style.display = 'block';
                rangeDateFields.style.display = 'none';
                document.getElementById('start_date').removeAttribute('required');
                document.getElementById('end_date').removeAttribute('required');
            } else {
                singleDateFields.style.display = 'none';
                rangeDateFields.style.display = 'block';
                document.getElementById('selected_date').removeAttribute('required');
                document.getElementById('start_date').setAttribute('required', '');
                document.getElementById('end_date').setAttribute('required', '');
            }
        }

        // Initial invocation
        toggleDateFields();

        // Event listener for date type change
        dateTypeSelect.addEventListener('change', toggleDateFields);
    });
</script>

@endsection
