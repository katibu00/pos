{{-- @extends('layouts.app')
@section('PageTitle', 'Expenses')
@section('content')
<section id="content">
    <div class="content-wrap">
        <div class="container">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Expenses Dashboard</h3>
                </div>
                <div class="card-body">
                    <p>Welcome to the Expenses Management Dashboard. Please use the menu to navigate to different sections.</p>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection --}}